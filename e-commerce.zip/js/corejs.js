var buttons  = document.quearySelectorAll(".ready_pro .ready_pro ul");
var tabpanel = document.quearySelectorAll(".tabpanel");

function showpanel(panelindex,colorcode){
	buttons.forEach(function(node){
		node.style.backgroundColor=''
	});
}
